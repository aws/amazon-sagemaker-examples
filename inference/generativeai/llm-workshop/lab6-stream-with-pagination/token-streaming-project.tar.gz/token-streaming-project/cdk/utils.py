import logging
from pathlib import Path
from typing import Dict, Optional


def read_serving_properties(file_path: Path) -> Dict[str, str]:
    model_server_config = {}
    with open(file_path, mode="r", encoding="utf-8") as file_handle:
        for line in file_handle:
            model_server_config.update([line.rstrip().split("=", 1)])
    return model_server_config


def write_serving_properties(config: Dict[str, str], file_path: Path, line_separator: Optional[str] = "\n") -> Path:
    with open(file_path, mode="w", encoding="utf-8") as file_handle:  # Overwrites any already existing file
        for option, option_value in config.items():
            file_handle.write(f"{option}={option_value}{line_separator}")
    return file_path


def remove_model_location_keys(config: Dict[str, str]) -> Dict[str, str]:
    for removed_option in ("option.s3url", "option.model_id"):
        try:
            config.pop(removed_option)
            logging.warning("Removed '%s' option from serving.properties", removed_option)
        except KeyError:
            pass
    return config
