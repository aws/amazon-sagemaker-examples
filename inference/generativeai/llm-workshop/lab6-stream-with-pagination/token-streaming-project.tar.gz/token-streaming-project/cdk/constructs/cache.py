from typing import Optional

from aws_cdk import RemovalPolicy
from aws_cdk import aws_dynamodb as ddb
from aws_cdk import aws_iam as iam
from constructs import Construct


class DynamoDBTokenCache(Construct):
    ALLOWED_READ_ACTIONS = [
        "dynamodb:GetItem",
    ]

    ALLOWED_WRITE_ACTIONS = [
        "dynamodb:UpdateItem",
    ]

    def __init__(
        self, scope: Construct, construct_id: str, *, removal_policy: Optional[RemovalPolicy] = RemovalPolicy.DESTROY
    ):
        super().__init__(scope=scope, id=construct_id)

        self._primary_key = ddb.Attribute(name="session-id", type=ddb.AttributeType.STRING)
        self._table = ddb.Table(
            scope=self,
            id="DynamoDBCacheTable",
            partition_key=self._primary_key,
            billing_mode=ddb.BillingMode.PAY_PER_REQUEST,
            removal_policy=removal_policy,
            table_class=ddb.TableClass.STANDARD,
        )

        self._read_policy = iam.Policy(
            scope=self,
            id="ReadPolicy",
            statements=[
                iam.PolicyStatement(
                    actions=self.ALLOWED_READ_ACTIONS, effect=iam.Effect.ALLOW, resources=[self._table.table_arn]
                ),
            ],
        )

        self._write_policy = iam.Policy(
            scope=self,
            id="WritePolicy",
            statements=[
                iam.PolicyStatement(
                    actions=self.ALLOWED_WRITE_ACTIONS, effect=iam.Effect.ALLOW, resources=[self._table.table_arn]
                ),
            ],
        )

    @property
    def name(self) -> str:
        return self._table.table_name

    @property
    def primary_key_name(self) -> str:
        return self._primary_key.name

    def grant_read(self, role: iam.IRole) -> iam.IRole:
        role.attach_inline_policy(policy=self._read_policy)

    def grant_write(self, role: iam.IRole) -> iam.IRole:
        role.attach_inline_policy(policy=self._write_policy)
