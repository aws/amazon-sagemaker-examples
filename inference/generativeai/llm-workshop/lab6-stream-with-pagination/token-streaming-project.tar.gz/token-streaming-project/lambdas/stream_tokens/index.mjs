import { DynamoDBClient, GetItemCommand } from "@aws-sdk/client-dynamodb";
import { SageMakerRuntimeClient, InvokeEndpointCommand } from "@aws-sdk/client-sagemaker-runtime";

function get_env_variable(varname, defaultvalue)
{
    var result = process.env[varname];
    if(result!=undefined)
        return result;
    else
        return defaultvalue;
}

// Environment variables retrieval
const cache_table_name = process.env.CACHE_TABLE_NAME;
const region_name = process.env.REGION_NAME;
const cache_table_primary_key_name = process.env.CACHE_TABLE_PRIMARY_KEY_NAME;
const sagemaker_endpoint_name = process.env.MODEL_ENDPOINT_NAME;
const cache_polling_interval_in_ms = parseInt(get_env_variable("CACHE_POLLING_INTERVAL_IN_MS", 50), 10);
const cache_miss_interval_in_ms = parseInt(get_env_variable("CACHE_MISS_RETRY_INTERVAL_IN_MS", 150), 10);
const max_retry_empty_cache = parseInt(get_env_variable("MAX_EMPTY_CACHE_RETRIES", 25), 10);

// AWS client objects
const ddb_client = new DynamoDBClient({region: region_name});
const smr_client = new SageMakerRuntimeClient({region: region_name});

// Utility functions
function create_invoke_endpoint_payload(body) {
  var parameters = {};
  if ("parameters" in body) {
    parameters = body["parameters"];
  }
  return {
      inputs: [body["inputs"]],
      parameters: parameters
    };
}

async function invoke_endpoint(task_payload) {
  const invoke_params = {
    EndpointName: sagemaker_endpoint_name,
    Body: Buffer.from(JSON.stringify(task_payload)),
  };
  const invoke_command = new InvokeEndpointCommand(invoke_params);
  return await smr_client.send(invoke_command);
}

function create_get_item_command(session_id) {
  var key_value = {};
  key_value[cache_table_primary_key_name] = {S: session_id};
  const getitem_input = {
        TableName: cache_table_name,
        Key: key_value,
        ProjectionExpression: "generated_sequence, is_generation_finished, has_eos_been_generated",
    };
  return new GetItemCommand(getitem_input);
}

function create_response_payload(token_id, text, is_generation_finished, has_eos_been_generated) {
  var details = null;
  console.info("is_generation_finished: " + JSON.stringify(is_generation_finished));
  console.info("has_eos_been_generated: " + JSON.stringify(has_eos_been_generated));
  if (is_generation_finished){
    if (has_eos_been_generated){
      details = {FinishReason: "eos_token"};
    } else {
      details = {FinishReason: "length"};
    }
  }
  return {
    token: {
      id: token_id,
      text: text,
      logprob: null,
      special: false,
    },
    generated_text: null,
    details: details,
    };
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function get_body(event){
  if (event.requestContext !== undefined) {
    // e.g. request submitted using clients like cURL
    if (event.isBase64Encoded){
      return JSON.parse(Buffer.from(event.body, "base64"));
    } else {
      return JSON.parse(Buffer.from(event.body));
    }
  } else {
    // e.g. request submitted using Lambda:InvokeWithResponseStream
    return event;
  }
}

function is_valid_request(event){
  if (event.requestContext !== undefined) {
    // e.g. request submitted using clients like cURL
    if (event.requestContext.http.path == "/" && event.requestContext.http.method == "POST"){
      return true;
    } else {
      return false;
    }
  } else {
    // e.g. request submitted using Lambda:InvokeWithResponseStream
    return true;
  }
}

export const handler = awslambda.streamifyResponse(async (event, responseStream, _context) => {
  console.info("event: " + JSON.stringify(event));
  console.info("context: " + JSON.stringify(_context));
  if (!is_valid_request(event)){
    throw Error("Bad request");
  } else {
    const body = get_body(event);
    console.info("body: " + JSON.stringify(body));


    // InvokeEndpoint: i.e. submit prediction request
    const task_payload = create_invoke_endpoint_payload(body);
    const invoke_response = await invoke_endpoint(task_payload);
    const invoke_response_body = JSON.parse(Buffer.from(invoke_response.Body));
    const session_id = invoke_response_body.session_id;
    console.info(`session_id: ${session_id}`);

    // Poll the DynamoDB cache table
    const getitem_command = create_get_item_command(session_id);
    var retrieved_sequence = "";
    var token_id = 0;
    var nb_retry_empty_cache = 1;
    var cache_hit = false;
    var is_generation_finished = false;
    var has_eos_been_generated = false;
    while (!is_generation_finished) {
      const getitem_response = await ddb_client.send(getitem_command);
      console.info("getitem_response: " + JSON.stringify(getitem_response));
      if (getitem_response.Item !== undefined){
        if (!cache_hit){
          console.info("The first generated tokens are being retrieved from cache");
          cache_hit=true;
        }
        const generated_sequence = getitem_response.Item.generated_sequence.S;
        is_generation_finished = getitem_response.Item.is_generation_finished.BOOL;
        has_eos_been_generated = getitem_response.Item.has_eos_been_generated.BOOL;
        if (generated_sequence.length == retrieved_sequence.length) {
          if (!is_generation_finished) {
            // No new tokens have been cached, avoids to post empty strings to the stream
            sleep(cache_polling_interval_in_ms);
          } else {
            responseStream.write(create_response_payload(token_id, "", is_generation_finished, has_eos_been_generated));
            continue;
          }
        } else {
          const new_tokens = generated_sequence.slice(retrieved_sequence.length);
          responseStream.write(create_response_payload(token_id, new_tokens, is_generation_finished, has_eos_been_generated));
          retrieved_sequence = generated_sequence;
          token_id += 1;
        }
      } else if (nb_retry_empty_cache <= max_retry_empty_cache) {
        // Cache has been queried too early, before the first token has been generated
        console.info(`Generated text is not yet available. Retry: ${nb_retry_empty_cache}`);
        nb_retry_empty_cache += 1;
        sleep(cache_miss_interval_in_ms);
        continue;
      } else {
        throw Error("Model endpoint internal error"); // Max retry exceeded
      }
      sleep(cache_polling_interval_in_ms);
    }
    responseStream.end();
  }
});
