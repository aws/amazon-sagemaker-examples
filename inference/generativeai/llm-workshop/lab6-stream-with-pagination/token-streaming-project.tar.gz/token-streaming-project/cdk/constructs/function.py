from typing import Dict, Optional

from aws_cdk import Duration
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda as lambda_
from constructs import Construct


class StreamingLambdaFunction(Construct):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        handler: str,
        code_asset_path: str,
        environment: Dict[str, str],
        role: iam.Role,
        timeout: Optional[Duration] = Duration.seconds(90),
    ):
        super().__init__(scope=scope, id=construct_id)

        environment_defaults = {
            "CACHE_POLLING_INTERVAL_IN_MS": str(50),
            "CACHE_MISS_RETRY_INTERVAL_IN_MS": str(150),
            "MAX_EMPTY_CACHE_RETRIES": str(40),
            "REGION_NAME": scope.region,
        }
        environment_defaults.update(environment)

        self._func = lambda_.Function(
            scope=self,
            id="StreamingLambdaFunction",
            code=lambda_.Code.from_asset(path=code_asset_path),
            environment=environment_defaults,
            handler=handler,
            runtime=lambda_.Runtime.NODEJS_18_X,
            role=role,
            timeout=timeout,
        )

        # The principal invoking the function with the URL must be granted the lambda:InvokeFunctionUrl permission for
        # the function
        self._url = lambda_.CfnUrl(
            scope=self,
            id="StreamingLambdaFunctionUrl",
            auth_type="AWS_IAM",
            target_function_arn=self._func.function_arn,
            cors=None,
            invoke_mode="RESPONSE_STREAM",
        )

    @property
    def arn(self) -> str:
        return self._func.function_arn
    
    @property
    def name(self) -> str:
        return self._func.function_name

    @property
    def url(self) -> str:
        return self._url.attr_function_url
