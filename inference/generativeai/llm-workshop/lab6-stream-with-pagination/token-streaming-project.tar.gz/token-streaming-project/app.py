#!/usr/bin/env python3
import logging.config
import os

import aws_cdk as cdk

from cdk.stack import TextGenerationServiceStack

PYTHON_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": True,
    "formatters": {
        "standard": {"format": "%(asctime)s [%(levelname)s] %(name)s - %(message)s"},
    },
    "handlers": {
        "default": {
            "level": "INFO",
            "formatter": "standard",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "root": {
            "handlers": ["default"],
            "level": "INFO",
        },
    },
}
# Logging configuration consists in:
#  - Disabling all existing loggers but the root logger
#  - Setting the root logger level to INFO (20)
#  - Attaching a single StreamHandler to the root logger (i.e. message are emitted to stdout)
logging.config.dictConfig(config=PYTHON_LOGGING_CONFIG)

tags = {"ManagedBy": "cdk", "Stack": "LLMEndpoint"}

env = cdk.Environment(account=os.getenv("CDK_DEFAULT_ACCOUNT"), region=os.getenv("CDK_DEFAULT_REGION"))

app = cdk.App()
TextGenerationServiceStack(scope=app, construct_id="TextGenerationServiceStack", tags=tags, env=env)
app.synth()
