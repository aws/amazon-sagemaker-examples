from __future__ import annotations

import os
import re
import tarfile
import tempfile
import zipfile
from pathlib import Path
from typing import List, Optional

from aws_cdk import RemovalPolicy
from aws_cdk import aws_iam as iam
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_s3_deployment as s3_deployment
from constructs import Construct


class CodeAssetsBucket(Construct):
    LOCAL_TMP_DIR_PATH = Path("./tmp")
    DESTINATION_KEY_PREFIX = "code"
    CODE_ASSETS_FILE_NAME = "sourcedir.tar.gz"

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        auto_delete_objects: Optional[bool] = True,
        removal_policy: Optional[RemovalPolicy] = RemovalPolicy.DESTROY,
    ):
        super().__init__(scope=scope, id=construct_id)

        self.bucket = s3.Bucket(
            scope=self,
            id="CodeAssetsBucket",
            auto_delete_objects=auto_delete_objects,
            removal_policy=removal_policy,
        )

        self.code_assets_uri = None

    def grant_read(self, role: iam.IRole) -> None:
        self.bucket.grant_read(role)

    def _build_endpoint_code_assets_archive(self, output_file_path: Path, source_file_paths: List[Path]) -> None:
        output_file_path.parent.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory() as tmp_dir_name:
            intermediate_file_path = Path(tmp_dir_name) / self.CODE_ASSETS_FILE_NAME
            with tarfile.open(intermediate_file_path, "w:gz") as tar_handle:
                for source_file_path in source_file_paths:
                    tar_handle.add(source_file_path, arcname=source_file_path.name)
            with zipfile.ZipFile(output_file_path, "w") as zip_handle:
                zip_handle.write(intermediate_file_path, arcname=intermediate_file_path.name)

    def upload_artifacts(self, local_source_dir_paths: List[Path]) -> s3_deployment.BucketDeployment:
        local_code_assets_path = self.LOCAL_TMP_DIR_PATH / "endpoint-code-bundle.zip"
        source_file_paths = []
        for source_dir_path in local_source_dir_paths:
            if source_dir_path.is_dir():
                source_file_paths.extend(
                    [Path(source_dir_path) / file_name for file_name in os.listdir(source_dir_path)]
                )
            else:
                source_file_paths.append(source_dir_path)
        self._build_endpoint_code_assets_archive(
            output_file_path=local_code_assets_path, source_file_paths=source_file_paths
        )
        deployment = s3_deployment.BucketDeployment(
            scope=self,
            id="DeployEndpointCodeAssets",
            sources=[s3_deployment.Source.asset(local_code_assets_path.as_posix())],
            destination_bucket=self.bucket,
            content_type="application/x-tar-gz",
            destination_key_prefix=self.DESTINATION_KEY_PREFIX,
        )
        self.code_assets_uri = (
            f"s3://{self.bucket.bucket_name}/{self.DESTINATION_KEY_PREFIX}/{self.CODE_ASSETS_FILE_NAME}"
        )
        return deployment


class ModelArtifactsBucket(Construct):
    ALLOWED_BUCKET_ACTIONS = [
        "s3:ListBucket",
    ]

    ALLOWED_OBJECTS_ACTIONS = [
        "s3:GetObject",
    ]

    def __init__(self, scope: Construct, construct_id: str, *, bucket_name: str, prefix: str) -> None:
        super().__init__(scope=scope, id=construct_id)
        self.bucket_name = bucket_name
        self.prefix = prefix

        self._artifacts_policy = iam.Policy(
            scope=self,
            id="ReadPolicy",
            statements=[
                iam.PolicyStatement(
                    actions=self.ALLOWED_BUCKET_ACTIONS,
                    effect=iam.Effect.ALLOW,
                    resources=[f"arn:aws:s3:::{self.bucket_name}"],
                ),
                iam.PolicyStatement(
                    actions=self.ALLOWED_OBJECTS_ACTIONS,
                    effect=iam.Effect.ALLOW,
                    resources=[f"arn:aws:s3:::{self.bucket_name}/{self.prefix}/*"],
                ),
            ],
        )

    @classmethod
    def from_uri(cls, scope: Construct, construct_id: str, uri: str) -> ModelArtifactsBucket:
        bucket_name, prefix = re.search(r"^s3://(.+)", uri).group(1).split("/", 1)
        return cls(scope=scope, construct_id=construct_id, bucket_name=bucket_name, prefix=prefix)

    def grant_read(self, role: iam.IRole) -> None:
        role.attach_inline_policy(policy=self._artifacts_policy)


class ImageRepository(Construct):
    AUTHENTICATION_ACTIONS = [
        "ecr:GetAuthorizationToken",
    ]
    ALLOWED_READ_ACTIONS = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:BatchGetImage",
        "ecr:GetDownloadUrlForLayer",
    ]

    def __init__(self, scope: Construct, construct_id: str, *, arn: str) -> None:
        super().__init__(scope=scope, id=construct_id)
        self.arn = arn
        self._pull_policy = iam.Policy(
            scope=self,
            id="PullPolicy",
            statements=[
                iam.PolicyStatement(actions=self.AUTHENTICATION_ACTIONS, effect=iam.Effect.ALLOW, resources=["*"]),
                iam.PolicyStatement(
                    actions=self.ALLOWED_READ_ACTIONS, effect=iam.Effect.ALLOW, resources=[f"{self.arn}*"]
                ),
            ],
        )

    @classmethod
    def from_uri(cls, scope: Construct, construct_id: str, uri: str) -> ImageRepository:
        account, region_name, repo_name = re.search(r"^([0-9]+).dkr.ecr.([a-z0-9-]+).amazonaws.com/(.+):", uri).groups()
        return cls(
            scope=scope, construct_id=construct_id, arn=f"arn:aws:ecr:{region_name}:{account}:repository/{repo_name}"
        )

    def grant_read(self, role: iam.IRole) -> None:
        role.attach_inline_policy(policy=self._pull_policy)
