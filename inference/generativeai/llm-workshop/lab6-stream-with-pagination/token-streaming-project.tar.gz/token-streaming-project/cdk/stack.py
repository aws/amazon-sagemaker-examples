import logging
import tempfile
from pathlib import Path
from typing import Any, Optional

import sagemaker
from aws_cdk import CfnOutput, Stack
from aws_cdk import aws_iam as iam
from constructs import Construct

from cdk.constructs.auth import CognitoIndentityPool
from cdk.constructs.cache import DynamoDBTokenCache
from cdk.constructs.endpoint import CodeAssetsBucket, ImageRepository, ModelArtifactsBucket, SageMakerEndpoint
from cdk.constructs.function import StreamingLambdaFunction
from cdk.constructs.identity import LambdaFunctionBaseRole, SageMakerEndpointBaseRole
from cdk.utils import read_serving_properties, remove_model_location_keys, write_serving_properties

# pylint: disable=too-many-locals


DEFAULT_CODE_SOURCE_DIR_PATH = "../code"
DEFAULT_ENDPOINT_INSTANCE_TYPE = "ml.g5.4xlarge"
DEFAULT_ENDPOINT_STARTUP_TIMEOUT_IN_S = 6 * 60
DEFAULT_REQUIRE_IDENTITY_POOL = "True"


class TextGenerationServiceStack(Stack):
    def get_context_value(self, name: str, default: Optional[Any] = None) -> Any:
        ctx_value = self.node.try_get_context(name)
        ctx_value = ctx_value if ctx_value is not None else default
        return ctx_value

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope=scope, id=construct_id, **kwargs)
        CfnOutput(scope=self, id="AccountID", value=self.account)

        sm_execution_role = SageMakerEndpointBaseRole(scope=self, construct_id="SageMakerExecutionRole").role

        lambda_function_role = LambdaFunctionBaseRole(
            scope=self,
            construct_id="StreamingLambdaFunctionRole",
        ).role

        source_dir_path = Path(self.get_context_value(name="CodeSourceDirPath", default="../code"))
        model_server_config = read_serving_properties(file_path=source_dir_path / "serving.properties")
        model_artifacts_uri = self.get_context_value(name="ModelArtifactsUri")
        if model_artifacts_uri is not None:
            model_artifacts_bucket = ModelArtifactsBucket.from_uri(
                scope=self, construct_id="ModelArtifactsBucket", uri=model_artifacts_uri
            )
            model_artifacts_bucket.grant_read(role=sm_execution_role)
            model_server_config = remove_model_location_keys(config=model_server_config)
            model_server_config.update({"option.s3url": model_artifacts_uri})
        else:
            logging.warning(
                (
                    "No ModelArtifactsUri could be retrieved from context: it is assumed that:\n  - Either the "
                    "option.s3url field of the serving.properties files is set with a valid Amazon S3 URI "
                    "pointing to uncompressed model artifacts and no read permissions need to be attached to "
                    "the role assumed by the Amazon SageMaker Endpoint\n  - Or the option.model_id field of "
                    "the serving.properties file is set with a valid HuggingFace Hub model ID. Model downloading "
                    "times can be significantly higher, adjust the EndpointStartupTimeoutInSec value accordingly"
                )
            )

        code_assets_bucket = CodeAssetsBucket(scope=self, construct_id="CodeAssetsBucket")
        code_assets_bucket.grant_read(role=sm_execution_role)
        with tempfile.TemporaryDirectory() as tmp_dir_name:
            serving_properties_file_path = write_serving_properties(
                config=model_server_config, file_path=Path(tmp_dir_name) / "serving.properties"
            )
            code_assets_deployment = code_assets_bucket.upload_artifacts(
                local_source_dir_paths=[source_dir_path, serving_properties_file_path],
            )
        code_assets_uri = code_assets_bucket.code_assets_uri

        image_uri = self.get_context_value(name="InferenceImageUri")
        if image_uri is None:
            framework_version = "0.22.1"
            logging.info(
                (
                    "No InferenceImageUri could be retrieved from context: falling back to Amazon SageMaker LMI image "
                    "(DJL version: %s)"
                ),
                framework_version,
            )
            image_uri = sagemaker.image_uris.retrieve(
                framework="djl-deepspeed", region=self.region, version=framework_version
            )
        image_repository = ImageRepository.from_uri(scope=self, construct_id="InferenceImageRepository", uri=image_uri)
        image_repository.grant_read(role=sm_execution_role)

        cache_table = DynamoDBTokenCache(scope=self, construct_id="TokenCacheTable")
        cache_table.grant_write(role=sm_execution_role)
        cache_table.grant_read(role=lambda_function_role)

        endpoint_environment = {
            "REGION_NAME": self.region,
            "CACHE_TABLE_NAME": cache_table.name,
            "CACHE_TABLE_PRIMARY_KEY_NAME": cache_table.primary_key_name,
        }
        sm_endpoint = SageMakerEndpoint(
            scope=self,
            construct_id="SageMakerEndpoint",
            code_assets_uri=code_assets_uri,
            image_uri=image_uri,
            environment=endpoint_environment,
            role=sm_execution_role,
            instance_type=self.get_context_value(name="EndpointInstanceType", default=DEFAULT_ENDPOINT_INSTANCE_TYPE),
            start_up_timeout_in_seconds=int(
                self.get_context_value(
                    name="EndpointStartupTimeoutInSec", default=DEFAULT_ENDPOINT_STARTUP_TIMEOUT_IN_S
                )
            ),
        )
        sm_endpoint.grant_invoke(role=lambda_function_role)
        sm_endpoint.node.add_dependency(sm_execution_role)
        sm_endpoint.node.add_dependency(code_assets_deployment)

        lambda_environment = {
            "CACHE_TABLE_NAME": cache_table.name,
            "CACHE_TABLE_PRIMARY_KEY_NAME": cache_table.primary_key_name,
            "MODEL_ENDPOINT_NAME": sm_endpoint.name,
            "REGION_NAME": self.region,
        }
        streaming_function = StreamingLambdaFunction(
            scope=self,
            construct_id="StreamingFunction",
            handler="index.handler",
            code_asset_path="lambdas/stream_tokens",
            role=lambda_function_role,
            environment=lambda_environment,
        )
        streaming_function.node.add_dependency(lambda_function_role)

        require_identity_pool = (
            self.get_context_value(name="RequireIdentityPool", default=DEFAULT_REQUIRE_IDENTITY_POOL).lower() == "true"
        )
        if require_identity_pool:
            identity_pool = CognitoIndentityPool(
                scope=self,
                construct_id="IdentityPool",
                unauthenticated_role_permissions=[
                    iam.PolicyStatement(
                        effect=iam.Effect.ALLOW,
                        actions=[
                            "lambda:InvokeFunction",  # Allows to invoke the function programmaticaly
                            "lambda:InvokeWithResponseStream",
                            "lambda:InvokeFunctionUrl",  # Allows to invoke the function using a HTTP client
                        ],
                        resources=[streaming_function.arn],
                    )
                ],
            )

            CfnOutput(scope=self, id="IdentityPoolId", value=identity_pool.id)


        CfnOutput(scope=self, id="TokenStreamingFunctionName", value=streaming_function.name)
        CfnOutput(scope=self, id="TokenStreamingFunctionUrl", value=streaming_function.url)
