from typing import List

# Pylint's import checker wrongfully assumes that aws_cognito_identitypool_alpha is a submodule from aws_cdk
# pylint: disable=import-error, no-name-in-module
import aws_cdk.aws_cognito_identitypool_alpha as cognito_constructs
from aws_cdk import aws_iam as iam
from constructs import Construct


class CognitoIndentityPool(Construct):
    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        unauthenticated_role_permissions: List[iam.PolicyStatement] = None,
        **kwargs,
    ) -> None:
        """
        This constructs creates the necessary resources to allow unauthenticated user to get temporary credentials and
        permissoions.
        See: https://docs.aws.amazon.com/cdk/api/latest/python/aws_cdk.aws_cognito_identitypool_alpha/index.html
        """
        super().__init__(scope=scope, id=construct_id, **kwargs)

        self._identity_pool = cognito_constructs.IdentityPool(
            scope=self,
            id="IdentityPool",
            allow_unauthenticated_identities=True,
        )

        # Attach permissions granted to unauthenticated users
        for policy_statement in unauthenticated_role_permissions:
            self._identity_pool.unauthenticated_role.add_to_principal_policy(policy_statement)

    @property
    def id(self) -> str:
        return self._identity_pool.identity_pool_id
