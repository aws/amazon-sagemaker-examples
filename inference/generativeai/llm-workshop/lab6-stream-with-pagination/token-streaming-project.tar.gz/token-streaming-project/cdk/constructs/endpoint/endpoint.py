import datetime
from typing import Dict, Optional

from aws_cdk import aws_iam as iam
from aws_cdk import aws_sagemaker as sm
from constructs import Construct


class SageMakerEndpoint(Construct):
    ALLOWED_INVOKE_ACTIONS = [
        "sagemaker:InvokeEndpoint",
    ]

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        *,
        environment: Dict[str, str],
        code_assets_uri: str,
        image_uri: str,
        instance_type: str,
        role: iam.Role,
        start_up_timeout_in_seconds: Optional[int] = 6 * 60,
    ):
        super().__init__(scope=scope, id=construct_id)

        # For immutable resource names
        # Model and ModelConfig immutable: code assets update -> rename Model -> destroy + recreate
        # Possible improvement: link immutable resource renaming to changes in code assets instead of build timestamp
        # Would allow more efficient stack updates
        deployment_ts = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

        sm_container_def = sm.CfnModel.ContainerDefinitionProperty(
            environment=environment,
            image=image_uri,
            model_data_url=code_assets_uri,
            mode="SingleModel",
        )

        sm_model = sm.CfnModel(
            scope=self,
            id="SageMakerModel",
            model_name=f"text-generation-stack-model-{deployment_ts}",
            primary_container=sm_container_def,
            execution_role_arn=role.role_arn,
            enable_network_isolation=False,
        )

        production_variant = sm.CfnEndpointConfig.ProductionVariantProperty(
            variant_name="AllTraffic",
            model_name=sm_model.model_name,
            instance_type=instance_type,
            initial_instance_count=1,
            initial_variant_weight=1.0,
            model_data_download_timeout_in_seconds=start_up_timeout_in_seconds,
            container_startup_health_check_timeout_in_seconds=start_up_timeout_in_seconds,
        )

        sm_endpoint_config = sm.CfnEndpointConfig(
            scope=self,
            id="SageMakerEndpointConfig",
            endpoint_config_name=f"text-generation-stack-endpoint-config-{deployment_ts}",
            production_variants=[production_variant],
        )
        sm_endpoint_config.add_dependency(target=sm_model)

        self.endpoint = sm.CfnEndpoint(
            scope=self,
            id="SageMakerEndpoint",
            endpoint_config_name=sm_endpoint_config.endpoint_config_name,
            endpoint_name=f"text-generation-stack-endpoint-{deployment_ts}",
        )
        self.endpoint.add_dependency(target=sm_endpoint_config)

        self._invoke_policy = iam.Policy(
            scope=self,
            id="InvokeEndpointPolicy",
            statements=[
                iam.PolicyStatement(
                    actions=self.ALLOWED_INVOKE_ACTIONS, effect=iam.Effect.ALLOW, resources=[self.endpoint.ref]
                ),
            ],
        )

    @property
    def name(self) -> str:
        return self.endpoint.endpoint_name

    def grant_invoke(self, role: iam.IRole) -> None:
        role.attach_inline_policy(policy=self._invoke_policy)
