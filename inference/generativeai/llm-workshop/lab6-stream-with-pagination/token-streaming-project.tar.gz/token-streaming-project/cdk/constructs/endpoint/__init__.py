from cdk.constructs.endpoint.assets import CodeAssetsBucket, ImageRepository, ModelArtifactsBucket
from cdk.constructs.endpoint.endpoint import SageMakerEndpoint
