from aws_cdk import aws_iam as iam
from constructs import Construct


class SageMakerEndpointBaseRole(Construct):
    def __init__(self, scope: Construct, construct_id: str) -> None:
        super().__init__(scope=scope, id=construct_id)

        # See https://docs.aws.amazon.com/sagemaker/latest/dg/sagemaker-roles.html#sagemaker-roles-createmodel-perms
        base_cw_permissions_policy = iam.PolicyDocument(
            statements=[
                iam.PolicyStatement(
                    actions=[
                        "cloudwatch:PutMetricData",
                        "logs:CreateLogGroup",
                        "logs:CreateLogStream",
                        "logs:DescribeLogStreams",
                        "logs:PutLogEvents",
                    ],
                    resources=["*"],
                )
            ]
        )

        self.role = iam.Role(
            scope=self,
            id=construct_id,
            assumed_by=iam.ServicePrincipal("sagemaker.amazonaws.com"),
            inline_policies={"SageMakerEndpointBasicLoggingPolicy": base_cw_permissions_policy},
        )


class LambdaFunctionBaseRole(Construct):
    def __init__(self, scope: Construct, construct_id: str) -> None:
        super().__init__(scope=scope, id=construct_id)

        self.role = iam.Role(
            scope=self,
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            id=construct_id,
            managed_policies=[
                iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AWSLambdaBasicExecutionRole")
            ],
        )
